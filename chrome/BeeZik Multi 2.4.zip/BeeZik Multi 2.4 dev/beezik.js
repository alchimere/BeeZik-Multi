
	/*
		Made by firetonton
		firetonton@gmail.com
	*/

var callTopBarUpdate = 'javascript:eval(document.getElementById(&quot;refreshTopBar&quot;).innerHTML)';

// Ajout de la barre supérieure
function	nextSongBar()
{
    var footer = document.getElementById('Header');
    var jsnexttimeout = 'javascript:document.location = \'#BeeZikExtCmd:Next\'; setTimeout(\'document.location = \\\'#BeeZikMulti\\\'\', 100);';

    backgroundURL = chrome.extension.getURL('bar_background.jpg');

    top_bar = '<div id="BeeZikExtNext" style="margin-left:auto; padding-right:20px; padding-left:20px; color:black; font-weight:bold; font-size:20px; font-family:Arial,Helvetica,sans-serif; z-index:42000; width:100%; height:45px; position:absolute; text-align:center;">';
    top_bar += '<a style="text-decoration:none;" href="' + jsnexttimeout + '"> <img src="' + chrome.extension.getURL('bouton_haut_page.png') + '"/> </a>';
    top_bar += '</div>';

    if (footer)
		footer.innerHTML = top_bar + footer.innerHTML;
}

// Remplacement des double quotes pour éviter quelques soucis
function	inhib(str)
{
    var	nb = str.split('%22').length - 1;

    for (var i = 0; i < nb; i++)
	str = str.replace('%22', '@dbquote;');
    return (str);
}

// Remplace les boutons de style de musique pour prendre en compte les +
function	replaceThemes()
{
    var themeList = document.getElementById('themeList');

    if (themeList)
    {
		var themeLinkTab = themeList.getElementsByTagName('a');

		for (var i = 0; i < themeLinkTab.length; i++)
		{
			if (themeLinkTab[i].id.substr(0, 6) == 'theme_')
			{
				var href = themeLinkTab[i].href;
				var content = themeLinkTab[i].innerHTML;

				themeLinkTab[i].innerHTML =	'<a id="BeeZikExtTheme" href="' + href + '" onclick=" document.location = \'' + href + '\'; " >' + content + "</a>";
				themeLinkTab[i].onclick = function() { return false; };
			}
		}
    }
}

// Remplace telecharger par ajouter
function	downloadToAdd()
{
    var plus_img = chrome.extension.getURL('add_cart.png');
    var as = document.getElementsByTagName("a");

    for (var i = 0; i < as.length; i++)
    {
		// Titres
		if ((as[i].href.indexOf('titre-') > -1)
			|| (as[i].href.indexOf('telecharger/') != -1 && as[i].href.indexOf('telecharger/a/') == -1 && as[i].href.indexOf('telecharger/p/') == -1))
		{
			if (as[i].innerHTML.substr(0,4) == "<img" && as[i].innerHTML.indexOf('/pochette/') == -1)
			{
				as[i].innerHTML = '<img src="' + plus_img + '"/ class="acheter">';
				as[i].href = 'javascript:document.location = "#BeeZikExt:' + inhib(as[i].href) + 'BeeZikExt:' + inhib(as[i].title) + '";'
								+ 'setTimeout(\'document.location = "#BeeZik Multi";\', 100);';
			}
		}
		// Albums
		/*else if (as[i].href.indexOf('album-') > -1
			|| as[i].href.indexOf('telecharger/p/') > -1)
		{
			if (as[i].innerHTML.indexOf('<img') > -1 && as[i].innerHTML.indexOf('/pochette/') == -1)// && as[i].parentElement.class != 'visuel')
			{
				as[i].innerHTML = '<img src="' + plus_img + '"/ class="acheter">';
				as[i].href = 'javascript:document.location = "#BeeZikExtCmd:AddAlbum->' + inhib(as[i].href) + '";'//BeeZikExt:' + inhib(as[i].title) + '";'
						+ 'setTimeout(\'document.location = "#BeeZik Multi";\', 100);';
			}
		}*/
    }

    var visuels = document.getElementsByTagName("div");
    var ok = false;

	for (var i= 0; i < visuels.length; i++)
		if (visuels[i].className == "visuel")
		{
			ok = false;
			for (var j = 0; j < visuels[i].children.length && ok == false; j++)
			{
				var a = visuels[i].children[0];

				if (a)
				{
					if (a.href)
					{
						//myalert("OK " + a.href);
						visuels[i].innerHTML += '<div style="margin-top:-20px; margin-left:2px">'
									+ '<a href="#" onclick="document.location=\'#BeeZikExtCmd:AddAlbum->' + inhib(a.href) + '\';'
									+ ' setTimeout(\'document.location = \\\'#BeeZik Multi\\\';\', 200); return false;">'
									+ '<img src="' + plus_img + '"></a></div>';
						ok = true;
					}
					else
					{
						a = visuels[i].children[0].children[0];
						if (a)
						{
							if (a.href)
							{
								visuels[i].innerHTML += '<div style="margin-top:-20px; margin-left:2px">'
											+ '<a href="#" onclick="document.location=\'#BeeZikExtCmd:AddAlbum->' + inhib(a.href) + '\';'
											+ ' setTimeout(\'document.location = \\\'#BeeZik Multi\\\';\', 200); return false;">'
											+ '<img src="' + plus_img + '"></a></div>';
								ok = true;
							}
						}
					}
				}
			}
		}
}

var maxAlert = 10;

function	myalert(str)
{
	if (maxAlert > 0)
	{
		alert(str);
		maxAlert--;
	}
}

replaceThemes();
downloadToAdd();
nextSongBar();


chrome.extension.sendRequest({func: "endBeezikJs"}, function(response){});

