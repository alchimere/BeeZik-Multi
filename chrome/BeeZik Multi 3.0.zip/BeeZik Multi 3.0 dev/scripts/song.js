/*
 *
 * Made by firetonton
 * firetonton@gmail.com
 *
 */

function	newSong(artist, title, id)
{
	return {
				artist		: artist,
				title		: title,
				downloaded	: 0,
				id			: parseInt(id)
			};
}

