
//document.addEventListener ('DOMNodeInserted', OnNodeInserted, false);

function OnNodeInserted (event) {
	var node = event.target;
	/*console.log ("Node '" + node + "'");*/
	node = jQuery(node);
	//console.log(node.attr('id'));
	if (node.attr('id') == 'col-right')
		console.log (jQuery(node).html());
	else if (node.attr('id') == 'biography') {
		//console.log('Parent : ' + node.parent().attr('id'));
		var ad = '  <script type="text/javascript"><!--\
				google_ad_client = "ca-pub-6825180217073838";\
				/* BeeZikMulti */\
				google_ad_slot = "9073268921";\
				google_ad_width = 300;\
				google_ad_height = 250;\
				//-->\
				</script>\
				<script type="text/javascript"\
				src="https://pagead2.googlesyndication.com/pagead/show_ads.js">\
				</script>';
				
		ad = '<div id="beezikmulti_ad" class="module pave ads">\
					<span class="shadow-top"></span>'
					+ ad +
					'</div>';
		
		google_ad_client = "ca-pub-6825180217073838";
		/* BeeZikMulti */
		google_ad_slot = "9073268921";
		google_ad_width = 300;
		google_ad_height = 250;
		
		var script = document.createElement( 'script' );
		script.type = 'text/javascript';
		//script.src = 'https://pagead2.googlesyndication.com/pagead/show_ads.js';
		script.text = 'alert(\'coucou\'); document.write(\'<span>plop</span>\');';
		//$("#someElement").append( script );
		alert(node.parent().html().length);
		node.parent().append(script);
		alert(node.parent().html().length);
					
		//console.log(ad);
		//jQuery(ad).insertBefore('#col-right .ads');
		//node.parent().append(ad);
	}
}


		google_ad_client = "ca-pub-6825180217073838";
		/* BeeZikMulti */
		google_ad_slot = "9073268921";
		google_ad_width = 300;
		google_ad_height = 250;
